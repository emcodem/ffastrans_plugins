﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Runtime.InteropServices;
namespace testprocessor
{
    class Program
    {
        //JObject JInputParameters contains the values of the json file from ffastrans.
        //JObject JInputParameters will contain static parameters from webgui and also dynamic per-job params from ffastrans
        static JObject JInputParameters;

        /// <summary>
        /// Main entry point, called when program is started
        /// </summary>
        /// <param name="args">commandline parameters</param>
        static void Main(string[] args)
        {
            //optional catch kill signal
            SetConsoleCtrlHandler(new HandlerRoutine(ConsoleCtrlCheck), true);

            //simulate some progress to ffastrans and 10 seconds activity, this should be shown on userinterface
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine("Progress " + i +"%"); //printing xx% in a line will cause ffastrans progress to be updated
                System.Threading.Thread.Sleep(1);
            }

            CheckInputs(args);
            
            string custom_vars = JInputParameters["proc_data"].ToString();
            Console.WriteLine("--------------INPUT VARS-------------");
            Console.WriteLine(custom_vars);

            //access some input 
            var inputs = JInputParameters["proc_data"]["inputs"].ToArray();
            for (int i = 0; i < inputs.Length; i++) {
                string input_id = inputs[i]["id"].ToString();
                if (input_id == "testinput") {
                    string input_value = inputs[i]["value"].ToString();
                    Console.WriteLine("TESTINPUT FOUND, value: " + input_value);
                }
            }

            //set some output
            var outputs = JInputParameters["proc_data"]["outputs"].ToArray();
            for (int i = 0; i < outputs.Length; i++)
            {   
                //you can use the output id field to identify if this is the output you want to set (id is defined on index.html)
                string output_id = outputs[i]["id"].ToString();
                if (output_id == "testoutput")
                {
                    outputs[i]["data"] = "Processor says: the time is: " + DateTime.Now.ToString() + " and my name is " + JInputParameters["path"].ToArray()[0]["name"];
                }
                if (output_id == "testoutput2")
                {
                    outputs[i]["data"] = "Also this value comes from csharp processor";
                }
            }
            //write file for ffastrans containing all output variables 
            //we can just use the input object, as long as we did set the output data we wanted to set (e.g. proc_data.outputs[0].data)           
            var out_file = JInputParameters["processor_output_filepath"].ToString();
            File.WriteAllText(out_file, JInputParameters.ToString(), Encoding.Unicode);
            Console.WriteLine("Output file: [" + JInputParameters["processor_output_filepath"] + "]");
            Console.WriteLine("Processor end...");
        }

        //OPTIONAL FUNCTIONS


        /// <summary>
        /// Validates if mandatory inputs are well formatted
        /// </summary>
        /// <param name="args">commandline args</param>
        static void CheckInputs(string[] args) {
            
            if (args.Length != 2)
                EndProgram("Did not get exactly 1 parameters on Commandline Input\nUsage: thisprogram.exe <file_with_json_params> <output_json_file>", 1);
            
            if (!File.Exists(args[0]))
                EndProgram("Input File does not exist: [" + args[0] + "]", 1);

            int MAX_INPUT_FILESIZE = 100000000;
            FileInfo f = new FileInfo(args[0]);
            if (f.Length > MAX_INPUT_FILESIZE) //only 100mb allowed, pervent memory overloading
                EndProgram("Input JSON parameter file is larger than 100MB: [" + args[0] + "]", 1);

            string outputfile = "";

            try
            {
                JInputParameters = JObject.Parse(File.ReadAllText(args[0]));
                outputfile = JInputParameters["processor_output_filepath"].ToString();
            }
            catch (Exception e)
            {
                EndProgram("Input file does not contain a json object: [" + args[0] + "] " + e.Message, 1);
            }

            try
            {
                var fs = File.OpenWrite(outputfile);
                fs.Close();                
            }
            catch (Exception e) {
                EndProgram("Output File cannot be opened for writing: [" + args[0] + "] " + e.Message, 1);
            }

        }

        static void EndProgram(string msg, int exitcode) {
            Console.WriteLine(msg);
            System.Environment.Exit(exitcode);
        }


        //catch kill signal (optional)
        [DllImport("Kernel32")]
        public static extern bool SetConsoleCtrlHandler(HandlerRoutine Handler, bool Add);
        public delegate bool HandlerRoutine(CtrlTypes CtrlType);

        public enum CtrlTypes
        {
            CTRL_C_EVENT = 0,
            CTRL_BREAK_EVENT,
            CTRL_CLOSE_EVENT,
            CTRL_LOGOFF_EVENT = 5,
            CTRL_SHUTDOWN_EVENT
        }

        private static bool ConsoleCtrlCheck(CtrlTypes ctrlType)
        {
            //user on ffastrans cancelled the job, we get a CTRL_C_EVENT
            //do whats needed to teardown your process (e.g. send cancel job to external transcoder api etc...)

            return false;//you must return false here, otherwise you will be forcefully killed by ffastrans
        }
        




    }
}
